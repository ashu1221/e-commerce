<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h4>Information</h4>
                <p><a href="about.php">About Us</a></p>
                <p><a href="contact.php">Contact Us</a></p>
            </div>
            
            <div class="col-md-4">
                <h4>My Account</h4>
                <p><a href="" class="text-center" type="button" data-toggle="modal" data-target="#loginModal">Login</a></p>
                <p><a href="signup.php">Sign Up</a></p>
            </div>

            <div class="col-md-4">
                <h4>Contact Us</h4>
                <p><span class="glyphicon glyphicon-phone"></span> : +91-123-0000000</p>
                <p><span class="glyphicon glyphicon-envelope"></span> : mobile@shoppee.com</p>
            </div>

        </div>
    </div>
</footer>